// Dark Mode Toggle
const darkModeToggle = document.getElementById("darkModeToggle");
const body = document.body;

// Check for saved user preference
if (localStorage.getItem("darkMode") === "enabled") {
    body.classList.add("dark-mode");
    darkModeToggle.textContent = "☀️ Light Mode";
}

darkModeToggle.addEventListener("click", () => {
    body.classList.toggle("dark-mode");
    if (body.classList.contains("dark-mode")) {
        localStorage.setItem("darkMode", "enabled");
        darkModeToggle.textContent = "☀️ Light Mode";
    } else {
        localStorage.setItem("darkMode", "disabled");
        darkModeToggle.textContent = "🌙 Dark Mode";
    }
});

// Review Submission
document.getElementById("reviewForm").addEventListener("submit", function (e) {
    e.preventDefault();

    let name = document.getElementById("reviewName").value;
    let email = document.getElementById("reviewEmail").value;
    let message = document.getElementById("reviewMessage").value;
    let reviewBox = document.getElementById("reviews");

    if (name && email && message) {
        let newReview = document.createElement("p");
        newReview.innerHTML = `<strong>${name}:</strong> ${message}`;
        reviewBox.appendChild(newReview);

        document.getElementById("reviewForm").reset();
        alert("Review submitted successfully!");
    } else {
        alert("Please fill in all fields.");
    }
});

// Counter Animation
function animateCounter(element, start, end, duration) {
    let range = end - start;
    let current = start;
    let increment = range / (duration / 10);

    let timer = setInterval(function () {
        current += increment;
        element.innerText = Math.floor(current);

        if (current >= end) {
            clearInterval(timer);
            element.innerText = end;
        }
    }, 10);
}

document.addEventListener("DOMContentLoaded", function () {
    let trustedUsers = document.getElementById("trustedUsers");
    let gigs = document.getElementById("gigs");
    let support = document.getElementById("support");

    animateCounter(trustedUsers, 100, 1500, 2000);
    animateCounter(gigs, 50, 1200, 2000);
    animateCounter(support, 20, 900, 2000);
});
